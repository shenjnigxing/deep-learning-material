# confirm mtcnn was installed correctly
import mtcnn
# show version
print(mtcnn.__version__)